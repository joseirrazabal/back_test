const usersData = [
  { username: "user1", password: "password1" },
  { username: "user2", password: "password2" },
  // Agrega más usuarios según sea necesario
];

export default usersData;
